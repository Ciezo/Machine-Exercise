javac ME2.java
jar -cfve ME2.jar ME2 ME2* 