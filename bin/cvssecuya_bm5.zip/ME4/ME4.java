/** DOCUMENTATION SECTION 
 * @author Cloyd Van S. Secuya
 * @section BM5
 * @student no.: 2020101812
 * @note 
 *      *  BUTTON1 == LEFT CLICK 
 *      *  BUTTON2 == SCROLL WHEEL CLICK 
 *      *  BUTTON3 == RIGHT CLICK 
 */



//PACKAGE SECTION 
package ME4; 



// IMPORT SECTION
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Frame;



public class ME4 extends Frame implements MouseListener, MouseMotionListener{

    // Graphics graphic = getGraphics();
    Color [] colors = new Color[] {  
        Color.black,
        Color.red,
        Color.blue,
        Color.green
    };

    public ME4() {
        addMouseListener(this);
        addMouseMotionListener(this);
        setTitle("Secuya_BM5 Simple Paint Application");
        add(new JLabel("Right Click to change colors"), BorderLayout.PAGE_START); 
        setSize(400, 400);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
             @Override
             public void windowClosing(WindowEvent we)
                 {
                 dispose();
                 System.exit(0);
             }
         });
    }

    public static void main(String[] args) {
        new ME4();
    }

    
    public void mouseClicked(MouseEvent e){
        Graphics graphic = getGraphics();

        // System.out.println("Mouse is clicked!"); 
        
        /** IMPORTANT NOTES 
         *  BUTTON1 == LEFT CLICK 
         *  BUTTON2 == SCROLL WHEEL CLICK 
         *  BUTTON3 == RIGHT CLICK 
         */

        int clicker = e.getButton(); 

        switch (clicker) {
            case MouseEvent.BUTTON1: 
                System.out.println("Left click!");
                graphic.setColor(colors[0]);
                graphic.fillRect(150, 150, 100, 100); 
                
                break;
            
            case MouseEvent.BUTTON2:
                System.out.println("Scroll wheel click");
                break; 

            case MouseEvent.BUTTON3:
                System.out.println("Right click");
                int picker = e.getClickCount(); 
                System.out.println(picker);
                
                
                switch (picker) {
                    case 1:
                    graphic.setColor(colors[0]);
                    graphic.fillRect(150, 150, 100, 100);
                    picker++;
                    break; 
                    
                    case 2:
                    graphic.setColor(colors[1]);
                    graphic.fillRect(150, 150, 100, 100);
                    picker++;
                    break; 
                    
                    case 3:
                    graphic.setColor(colors[2]);
                    graphic.fillRect(150, 150, 100, 100);
                    picker++;
                    break; 
                    
                    case 4: 
                    graphic.setColor(colors[3]);
                    graphic.fillRect(150, 150, 100, 100);
                    picker++;
                    break; 
                }
                
                // for (int i = 0; i < 4; i++) {
                //     if (i == 0)
                //         graphic.setColor(colors[0]);
                    
                //     else if (i == 1)
                //         graphic.setColor(colors[1]);
                    
                //     else if (i == 2)
                //         graphic.setColor(colors[2]);    
        
                //     else if (i == 3)
                //         graphic.setColor(colors[3]);
        
                //     graphic.fillRect(150, 150, 100, 100); 
                // }
                
                break; 
            }
            
        }
        
    public void mousePressed(MouseEvent e){
    }

    public void mouseReleased(MouseEvent e){
    }

    public void mouseEntered(MouseEvent e){
        System.out.println("Mouse entered");
        setBackground(Color.white);
        repaint();
    }

    public void mouseExited(MouseEvent e){
        System.out.println("Mouse exited");
        setBackground(Color.gray);
    }

    
    public void mouseDragged(MouseEvent e) {       
    }

    public void mouseMoved(MouseEvent e){
    }
    
    // public void paint(Graphics g) {
    //     g.setColor(colors[0]);
    //     g.fillRect(150, 150, 100, 100);
    // }
}